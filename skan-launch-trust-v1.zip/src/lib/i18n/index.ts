import { useCallback } from "react";
import { useSettings } from "@/lib/settings-store";
import type { Lang } from "@/lib/lang";
import { en } from "./en";
import { ru, type MessageKey } from "./ru";

export type { MessageKey };

const DICTS: Record<Lang, Record<MessageKey, string>> = { ru, en };

/** BCP 47 locale for dates and numbers. */
export const LOCALE: Record<Lang, string> = { ru: "ru-RU", en: "en-US" };

export function translate(lang: Lang, key: MessageKey, vars?: Record<string, string | number>): string {
  const template = DICTS[lang][key] ?? ru[key] ?? key;
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (_, name: string) => (name in vars ? String(vars[name]) : `{${name}}`));
}

/** `t("scan.title")` in the current interface language. */
export function useT() {
  const lang = useSettings((s) => s.lang);
  return useCallback((key: MessageKey, vars?: Record<string, string | number>) => translate(lang, key, vars), [lang]);
}

/** "5 minutes ago" in the interface language, with a safe fallback for locales the browser lacks. */
export function timeAgo(lang: Lang, at: number, now = Date.now()): string {
  const diff = Math.round((at - now) / 1000);
  const abs = Math.abs(diff);
  const [value, unit]: [number, Intl.RelativeTimeFormatUnit] =
    abs < 60 ? [diff, "second"] : abs < 3600 ? [Math.round(diff / 60), "minute"] : abs < 86400 ? [Math.round(diff / 3600), "hour"] : [Math.round(diff / 86400), "day"];
  for (const locale of [LOCALE[lang], "en-US"]) {
    try {
      return new Intl.RelativeTimeFormat(locale, { numeric: "auto" }).format(value, unit);
    } catch {
      /* try the next locale */
    }
  }
  return new Date(at).toLocaleString();
}

export function formatDate(lang: Lang, at: number): string {
  for (const locale of [LOCALE[lang], "ru-RU"]) {
    try {
      return new Date(at).toLocaleString(locale, { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
    } catch {
      /* next */
    }
  }
  return new Date(at).toISOString();
}

/** "14 Mar 2024" in the interface language (ISO date or ms). */
export function formatDay(lang: Lang, at: string | number): string {
  const date = new Date(at);
  if (Number.isNaN(date.getTime())) return "—";
  for (const locale of [LOCALE[lang], "en-US"]) {
    try {
      return date.toLocaleDateString(locale, { day: "numeric", month: "short", year: "numeric" });
    } catch {
      /* next */
    }
  }
  return date.toISOString().slice(0, 10);
}
